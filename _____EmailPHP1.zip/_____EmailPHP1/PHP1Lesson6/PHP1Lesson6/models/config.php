﻿<?php
$pHOTOSMALL = "img/icons/";
$pHOTOBIG = "img/pics/";
?>