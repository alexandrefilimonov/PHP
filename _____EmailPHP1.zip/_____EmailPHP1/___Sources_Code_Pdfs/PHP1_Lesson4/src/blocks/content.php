<form action="server.php" method="POST" enctype="multipart/form-data">
	<p>Выберите файл для загрузки</p>
	<input type="file" name="photo" accept="image/*"><br><br>
	<input type="submit" value="Загрузить">
</form>

<?
/*$file = fopen("files/test.txt","r+");
while(!feof($file)){
	echo fgets($file);
}

fwrite($file,"test!!!");
*/