﻿<table border="1" width="100%" height="100%">
	<tr height=10%>
		<td colspan='3'><?include "blocks/header.php"?></td>
	</tr>
	<tr>
		<td width=20%><?include "blocks/left.php"?></td>
		<td><?include "blocks/content.php"?></td>
		<td width=20%>Правое меню</td>
	</tr>
	<tr height=10%>
		<td height=10% colspan='3'>
			Подвал сайта
		</td>
	</tr>
</table>