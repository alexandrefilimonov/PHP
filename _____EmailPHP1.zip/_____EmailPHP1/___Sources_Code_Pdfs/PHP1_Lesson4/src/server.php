<?
//print_r($_FILES);
$path = "files/".$_FILES['photo']['name'];//путь к нашему конечному файлу 

if(move_uploaded_file($_FILES['photo']['tmp_name'],$path)){
	echo "Файл ".$_FILES['photo']['name']." успешно загружен";
}
else{
	echo "Error!!!";
}