<?

$data = file_get_contents("http://www.foxnews.com/");
file_put_contents("data.html",$data);

echo file_get_contents("data.html");