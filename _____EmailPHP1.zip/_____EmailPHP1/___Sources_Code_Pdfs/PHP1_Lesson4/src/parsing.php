<?
$url = "http://site.ru/test/file.php";
$name = pathinfo($url);
echo $name[basename]; 