<?
$title = "Контакты";

$content = "templates/contacts.php";

$demo = "Demo!!!";

include "templates/main.php";