<html>
  <head>
	<meta charset="UTF-8">
	<title><?=$title?></title>
  </head>
  <body bgcolor="gray">
	<h1><?=$title?></h1>		
	<?
		include $content;
	?>
  </body>
</html>