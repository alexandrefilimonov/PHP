<?php
define("MYSQL_SERVER","localhost");
define("MYSQL_USER","root");
define("MYSQL_PASSWORD","");
define("MYSQL_DB","shop");

define("DIR_BIG","uploads/");
define("DIR_SMALL","uploads/mini/");

define("COLS",3);
