            'enablePrettyUrl' => true,
            'showScriptName' => false,
            'rules' => [
            	'<controller>/<action>/<id:\d+>' => '<controller>/<action>',
            ],
        ],
    ],