<?
include "config.php";

$sql = "select * from shop";

$res = mysqli_query($connection,$sql);

while($data = mysqli_fetch_assoc($res)){
	echo $data[name]." стоит ".$data[price]."<br>";
}
