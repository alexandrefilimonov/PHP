<?
	if(isset($_GET[success])){
		echo "Вы успешно авторизованы в системе";
	}
	else{
?>

<form action="server.php" method="POST">
	<p>Логин</p>
	<input type="text" name="login" value="<?=$_COOKIE[login]?>">
	<p>Пароль</p>
	<input type="password" name="pass" value="<?=$_COOKIE[pass]?>"><br><br>
	<input type="submit" name="send">
</form>
<?
	}
?>