<?
if(setcookie("name","Ivan")){
	echo "created";
}
