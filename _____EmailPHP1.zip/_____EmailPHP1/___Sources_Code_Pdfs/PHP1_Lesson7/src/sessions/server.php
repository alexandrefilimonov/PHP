<?

$login = strip_tags($_POST[login]);
$pass = strip_tags($_POST[pass]);

$connect = mysqli_connect("localhost","root","","shop");
$sql = "select * from users where login='$login' and pass=md5('$pass')";
$res = mysqli_query($connect,$sql);
if(mysqli_num_rows($res)>0){
  echo "Вы успешно авторизованы!!!";
}
else{
	echo "Введенные логин и пароль отсутствуют в базе данных";
}
