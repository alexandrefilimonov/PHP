<?
echo $_COOKIE[name];