<?
$price = 1200;
if($price>500 && $price<=1000){
	$price=$price-$price*0.05;
}
elseif($price>1000){
	$price=$price-$price*0.1;
}