<?
function sum($x=1,$y=1){
	$z=$x+$y;//локальная переменная
	return $z;
	//echo $z."<br>";
}

function show($x,$y){
	$result = sum($x,$y);
	echo "Сумма = $result";
}

show(2,3);


/*$x = 2 * sum(5);
echo $x;*/

