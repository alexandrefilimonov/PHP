<?
/*
function f($x){
	if($x==0){
		return;		
	}
	echo $x." ";
	f($x-1);		
}
f(5);
*/
/*
5! = 1*2*3*4*5=5*4!;
0!=1;
n! = n*(n-1)!
*/

function fact($n){
	if($n==1 || $n==0){
		return 1;
	}
	return $n*fact($n-1);
}

echo fact(5);






