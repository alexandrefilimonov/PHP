<?
$id = $_GET['id'];
$day = $_GET['day'];

switch($day){
	case 6:
		echo "Суббота";
		break;
	case 0:
		echo "Воскресенье";
		break;
	case 1:
	case 2:
	case 3:
	case 4:
	case 5:
		echo "Будний день";
		break;
	default:
		echo "Указан неверный день!";
		
	
	
	
}