<?
$svetophor = "red,yellow";
switch($svetophor){
	case "red":
		echo "Стоп!";
		break;
	case "yellow":
		echo "Внимание!";
		break;
	case "green":
		echo "Вперед!";
		break;
	default:
		echo "Поломка!";
}

