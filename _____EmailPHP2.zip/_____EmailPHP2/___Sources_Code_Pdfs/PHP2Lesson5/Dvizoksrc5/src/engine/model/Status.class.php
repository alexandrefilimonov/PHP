<?php

class Status
{
    const Deleted = 0;
    const Active = 1;
    const Inactive = 2;
}