<?php

class OrderStatus extends Status
{
    const Payed = 3;
    const Delivered = 4;
}