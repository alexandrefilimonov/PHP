<html>
<head>
    <title><?=$title?></title>
</head>
<body>
    <?include $content;?>
</body>
</html>