<img src="<?=$img[id].".".$img[type]?>">
